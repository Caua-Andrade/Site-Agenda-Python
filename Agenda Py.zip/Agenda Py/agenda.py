import os
from tabulate import tabulate

# Função para limpar o terminal
def limpar_terminal():
    os.system('cls' if os.name == 'nt' else 'clear')

# Função para adicionar cores ao texto
def colorize(text, color):
    colors = {
        "red": "\033[31m",
        "green": "\033[32m",
        "yellow": "\033[33m",
        "blue": "\033[34m",
        "magenta": "\033[35m",
        "cyan": "\033[36m",
        "white": "\033[37m",
        "reset": "\033[0m"  # Reset to default color
    }
    return f"{colors[color]}{text}{colors['reset']}"

# Dados para a tabela
dados = [
    [colorize("Cauã Andrade", "blue"), colorize("Responsável pela implementação do código e desenvolvimento do site da aplicação.", "cyan")],
    [colorize("Felipe Sousa", "blue"), colorize("Responsável pela criação do conteúdo escrito e auxiliou em todas as partes do projeto.", "cyan")],
    [colorize("Professor Lindolfo", "blue"), colorize("Ministrou as aulas, orientou o desenvolvimento do projeto e ofereceu suporte técnico durante o processo.", "cyan")]
]

# Definindo os cabeçalhos
cabecalhos = [colorize("Responsável", "yellow"), colorize("Função", "yellow")]

# Exibindo a tabela no terminal com estilo simples e colorido
limpar_terminal()  # Limpar o terminal
print(tabulate(dados, headers=cabecalhos, tablefmt="fancy_grid"))

inicio = str(input(colorize("Clique em qualquer tecla para continuar: ", "green")))

def menu():
    voltarMenuPrincipal = 's'
    while voltarMenuPrincipal == 's':
        limpar_terminal()  # Limpar o terminal antes de mostrar o menu
        opcao = input(f'''
{colorize("="*100, "yellow")}
                    {colorize("AGENDA EM PYTHON", "blue")}
{colorize("="*100, "yellow")}
                                        {colorize("MENU", "magenta")}
            
        {colorize("[1] ADICIONAR ITEM", "cyan")}
        {colorize("[2] VER TODOS OS ITENS", "cyan")}
        {colorize("[3] DELETAR ITEM", "cyan")}
        {colorize("[4] BUSCAR ITEM PELO ID", "cyan")}
        {colorize("[5] MODIFICAR ITEM", "cyan")}
        {colorize("[6] SAIR", "cyan")}
            
{colorize("="*100, "yellow")}
        {colorize("ESCOLHA UMA DAS OPÇÕES ACIMA:", "green")} ''')

        if opcao == "1":
            adicionaritem()
        elif opcao == "2":
            listaritem()
        elif opcao == "3":
            deletaritem()
        elif opcao == "4":
            buscarporid()
        elif opcao == "5":
            atualizaritem()
        elif opcao == "6":
            sair()
        else:
            print(colorize("Opção inválida! Por favor, escolha uma opção válida.", "red"))
        
        voltarMenuPrincipal = input(colorize("Deseja voltar ao menu principal? (s/n): ", "green")).lower()

def atualizaritem():
    idDeletado = input("Digite o ID para ser MODIFICADO: ")
    agenda = open("agenda.txt","r")
    auxiliar = []
    auxiliar2 = []
    for i in agenda:
        auxiliar.append(i)
    for i in range(0, len(auxiliar)):
        if idDeletado not in auxiliar[i]:
            auxiliar2.append(auxiliar[i])
    agenda = open("agenda.txt","w")
    for i in auxiliar2:
        agenda.write(i)
    idItem = input("Digite um NOVO ID (Número de identificação) do item: ")
    nome = input("Digite o NOVO nome do item: ")
    data = input("Digite uma NOVA data: ")
    horas = input("Que horas você irá fazer essa tarefa? ")
    try:
        agenda = open("agenda.txt", "a")
        dados = f' {idItem};{nome};{data};{horas} \n'
        agenda.write(dados)
        agenda.close()
        print(colorize(f'Item MODIFICADO com sucesso!!!', "green"))
    except:
        print(colorize("ERRO na gravação do item", "red"))

def adicionaritem():
    idItem = input("Digite o ID (Número de identificação) do item: ")
    nome = input("Digite o nome do item: ")
    data = input("Qual a data para essa tarefa? ")
    horas = input("Que horas você irá fazer essa tarefa? ")
    try:
        agenda = open("agenda.txt", "a")
        dados = f' {idItem};{nome};{data};{horas} \n'
        agenda.write(dados)
        agenda.close()
        print(colorize(f'Item gravado com sucesso!!!', "green"))
    except:
        print(colorize("ERRO na gravação do item", "red"))

def listaritem():
    agenda = open("agenda.txt", "r")
    for nome in agenda:
        print(nome)
    agenda.close()

def deletaritem():
    idDeletado = input("Digite o ID para ser deletado: ")
    agenda = open("agenda.txt", "r")
    auxiliar = []
    auxiliar2 = []
    for i in agenda:
        auxiliar.append(i)
    for i in range(0, len(auxiliar)):
        if idDeletado not in auxiliar[i]:
            auxiliar2.append(auxiliar[i])
    agenda = open("agenda.txt", "w")
    for i in auxiliar2:
        agenda.write(i)
    print(colorize(f'Item DELETADO com sucesso', "green"))
    listaritem()

def buscarporid():
    idnumero = input(f'Digite o ID a ser procurado: ')
    agenda = open("agenda.txt", "r")
    encontrado = False
    for nome in agenda:
        if idnumero in nome.split(";")[0]:
            print(nome)
            encontrado = True
    if not encontrado:
        print(colorize("ERRO : Item não encontrado", "red"))
    agenda.close()

def sair():
    print(colorize('Até logo... !!!', "magenta"))
    exit()

def main():
    menu()

main()
